#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

#ifdef CONFIG_UNWINDER_ORC
#include <asm/orc_header.h>
ORC_HEADER;
#endif

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

KSYMTAB_FUNC(dx_pcie_get_dev_num, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_get_download_region, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_get_download_size, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_get_booting_region, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_get_init_completed, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_set_init_completed, "_gpl", "");
KSYMTAB_FUNC(xpdev_create_interfaces, "_gpl", "");
KSYMTAB_FUNC(xpdev_release_interfaces, "_gpl", "");
KSYMTAB_FUNC(dx_cdev_init, "_gpl", "");
KSYMTAB_FUNC(dx_cdev_cleanup, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_get_driver_info, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_interrupt, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_interrupt_clear, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_interrupt_event, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_interrupt_wakeup, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_interrupt_event_wakeup, "_gpl", "");
KSYMTAB_FUNC(dx_sgdma_write, "_gpl", "");
KSYMTAB_FUNC(dx_sgdma_read, "_gpl", "");
KSYMTAB_FUNC(dx_sgdma_init, "_gpl", "");
KSYMTAB_FUNC(dx_sgdma_deinit, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_get_message_area, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_get_log_area, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_get_dl_area, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_get_request_queue, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_clear_response_queue, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_is_response_queue_empty, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_dequeue_response, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_enqueue_event_response, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_dequeue_event_response, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_clear_event_response, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_notify_msg_to_device, "_gpl", "");
KSYMTAB_FUNC(dx_pcie_notify_req_to_device, "_gpl", "");

SYMBOL_CRC(dx_pcie_get_dev_num, 0x799c15a5, "_gpl");
SYMBOL_CRC(dx_pcie_get_download_region, 0x96375987, "_gpl");
SYMBOL_CRC(dx_pcie_get_download_size, 0x9f6c145f, "_gpl");
SYMBOL_CRC(dx_pcie_get_booting_region, 0xe1e7a493, "_gpl");
SYMBOL_CRC(dx_pcie_get_init_completed, 0x63be5207, "_gpl");
SYMBOL_CRC(dx_pcie_set_init_completed, 0x1ccbceca, "_gpl");
SYMBOL_CRC(xpdev_create_interfaces, 0x32dc1050, "_gpl");
SYMBOL_CRC(xpdev_release_interfaces, 0x1957d65c, "_gpl");
SYMBOL_CRC(dx_cdev_init, 0x2af90a5b, "_gpl");
SYMBOL_CRC(dx_cdev_cleanup, 0xd3303193, "_gpl");
SYMBOL_CRC(dx_pcie_get_driver_info, 0xdf4fad68, "_gpl");
SYMBOL_CRC(dx_pcie_interrupt, 0x645da062, "_gpl");
SYMBOL_CRC(dx_pcie_interrupt_clear, 0x3d26254e, "_gpl");
SYMBOL_CRC(dx_pcie_interrupt_event, 0x018e1731, "_gpl");
SYMBOL_CRC(dx_pcie_interrupt_wakeup, 0xe4cb9af1, "_gpl");
SYMBOL_CRC(dx_pcie_interrupt_event_wakeup, 0x98ff5b35, "_gpl");
SYMBOL_CRC(dx_sgdma_write, 0x4e28dccd, "_gpl");
SYMBOL_CRC(dx_sgdma_read, 0x9a3c9869, "_gpl");
SYMBOL_CRC(dx_sgdma_init, 0x9d9d70e6, "_gpl");
SYMBOL_CRC(dx_sgdma_deinit, 0xad0bf482, "_gpl");
SYMBOL_CRC(dx_pcie_get_message_area, 0xd545a0fc, "_gpl");
SYMBOL_CRC(dx_pcie_get_log_area, 0xe8765b54, "_gpl");
SYMBOL_CRC(dx_pcie_get_dl_area, 0xfda406b8, "_gpl");
SYMBOL_CRC(dx_pcie_get_request_queue, 0x9b9ef2b1, "_gpl");
SYMBOL_CRC(dx_pcie_clear_response_queue, 0x39e7916b, "_gpl");
SYMBOL_CRC(dx_pcie_is_response_queue_empty, 0x2699c5f1, "_gpl");
SYMBOL_CRC(dx_pcie_dequeue_response, 0x6106b455, "_gpl");
SYMBOL_CRC(dx_pcie_enqueue_event_response, 0x269ac578, "_gpl");
SYMBOL_CRC(dx_pcie_dequeue_event_response, 0x08134286, "_gpl");
SYMBOL_CRC(dx_pcie_clear_event_response, 0xb677b970, "_gpl");
SYMBOL_CRC(dx_pcie_notify_msg_to_device, 0x2ec2012f, "_gpl");
SYMBOL_CRC(dx_pcie_notify_req_to_device, 0x91193f38, "_gpl");

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x587f22d7, "devmap_managed_key" },
	{ 0xc1514a3b, "free_irq" },
	{ 0xd3c2b982, "pcie_capability_read_word" },
	{ 0x1e2abf24, "get_user_pages_fast" },
	{ 0xa78af5f3, "ioread32" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0x17e85e4b, "vchan_init" },
	{ 0x204c4f87, "pci_find_ext_capability" },
	{ 0xf8ca6a78, "simple_attr_open" },
	{ 0x4239c21d, "param_ops_uint" },
	{ 0xde91da55, "debugfs_attr_write" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0xa193b721, "devm_kmalloc" },
	{ 0x4a453f53, "iowrite32" },
	{ 0x7f02188f, "__msecs_to_jiffies" },
	{ 0x55ae8e20, "dma_async_device_unregister" },
	{ 0x85826c26, "pci_alloc_irq_vectors" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xd29a050d, "sched_set_normal" },
	{ 0xc8c85086, "sg_free_table" },
	{ 0x53cfe3a2, "debugfs_create_u16" },
	{ 0x92540fbf, "finish_wait" },
	{ 0x75646747, "class_destroy" },
	{ 0xe067206b, "__pci_register_driver" },
	{ 0x7d628444, "memcpy_fromio" },
	{ 0x21fcdd63, "remap_pfn_range" },
	{ 0x37a0cba, "kfree" },
	{ 0xde97b422, "pci_sriov_get_totalvfs" },
	{ 0x5f1ea823, "dma_release_channel" },
	{ 0x44be8471, "pcpu_hot" },
	{ 0x7369f212, "seq_lseek" },
	{ 0x9c2073a, "__put_devmap_managed_page_refs" },
	{ 0xc3055d20, "usleep_range_state" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0xe2964344, "__wake_up" },
	{ 0xa32bb6d, "pci_irq_vector" },
	{ 0xf861aacd, "kmem_cache_create" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xf8145464, "__dynamic_dev_dbg" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x69e8d0a5, "pci_unregister_driver" },
	{ 0xd4156a97, "__dma_request_channel" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x7f24de73, "jiffies_to_usecs" },
	{ 0x1da62f8b, "pci_read_config_dword" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0x122c3a7e, "_printk" },
	{ 0xcc0e8ef6, "vchan_dma_desc_free_list" },
	{ 0x1000e51, "schedule" },
	{ 0x8ddd8aad, "schedule_timeout" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x983e624e, "pm_runtime_enable" },
	{ 0x6383b27c, "__x86_indirect_thunk_rdx" },
	{ 0x87a21cb3, "__ubsan_handle_out_of_bounds" },
	{ 0x7cd8d75e, "page_offset_base" },
	{ 0x599fb41c, "kvmalloc_node" },
	{ 0xb3f985a8, "sg_alloc_table" },
	{ 0xbcb36fe4, "hugetlb_optimize_vmemmap_key" },
	{ 0xd1cab96f, "pci_find_capability" },
	{ 0xea3c74e, "tasklet_kill" },
	{ 0x4aa25a97, "debugfs_attr_read" },
	{ 0x34c06377, "pcim_iomap_regions" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0x98378a1d, "cc_mkdec" },
	{ 0xfe15742c, "_dev_err" },
	{ 0xff64c876, "debugfs_create_file_unsafe" },
	{ 0x8c8569cb, "kstrtoint" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0x256df227, "simple_attr_release" },
	{ 0x3fed2fd6, "irq_get_irq_data" },
	{ 0x6ca9b86a, "class_create" },
	{ 0x4c03a563, "random_kmalloc_seed" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0x6a7a92b8, "debugfs_remove" },
	{ 0xd34403ef, "pci_read_config_word" },
	{ 0x8b797b14, "seq_putc" },
	{ 0xd18f8813, "vchan_tx_desc_free" },
	{ 0x9166fada, "strncpy" },
	{ 0x9d2ab8ac, "__tasklet_schedule" },
	{ 0x4c9d28b0, "phys_base" },
	{ 0x53a1e8d9, "_find_next_bit" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0xabb7c7c2, "get_cached_msi_msg" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x8d830b43, "_dev_warn" },
	{ 0x7afd69b6, "pci_set_master" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xf8d1e162, "debugfs_create_u32" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0x7524dc58, "dma_async_device_register" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x15ba50a6, "jiffies" },
	{ 0xf1a358b2, "dma_set_coherent_mask" },
	{ 0xc1d9b323, "seq_read" },
	{ 0x97651e6c, "vmemmap_base" },
	{ 0xa648e561, "__ubsan_handle_shift_out_of_bounds" },
	{ 0xea9a721b, "debugfs_create_file" },
	{ 0x6091b333, "unregister_chrdev_region" },
	{ 0xa775741e, "__pm_runtime_resume" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x41bf587, "dma_async_tx_descriptor_init" },
	{ 0xfbe215e4, "sg_next" },
	{ 0x9cbc9023, "__folio_put" },
	{ 0x5b40b481, "device_destroy" },
	{ 0x2cf56265, "__dynamic_pr_debug" },
	{ 0xb43f9365, "ktime_get" },
	{ 0xc00e2b80, "seq_printf" },
	{ 0x3b50b933, "pci_find_next_ext_capability" },
	{ 0x4d9138cb, "pci_disable_sriov" },
	{ 0xb98a4b4d, "set_page_dirty_lock" },
	{ 0xc07351b3, "__SCT__cond_resched" },
	{ 0xe16cab4a, "boot_cpu_data" },
	{ 0x8e66928c, "single_release" },
	{ 0x6f584963, "dma_set_mask" },
	{ 0x9ef4e442, "sched_set_fifo" },
	{ 0x1d8f10ec, "dma_unmap_sg_attrs" },
	{ 0xa4191c0b, "memset_io" },
	{ 0xd0c3484c, "kmalloc_trace" },
	{ 0x2a19f8a8, "pcim_iomap_table" },
	{ 0x46cf10eb, "cachemode2protval" },
	{ 0x204b50f5, "pci_read_config_byte" },
	{ 0x54b1fac6, "__ubsan_handle_load_invalid_value" },
	{ 0x7aa1756e, "kvfree" },
	{ 0x46b0be46, "single_open" },
	{ 0x3de60d26, "pcim_enable_device" },
	{ 0x21b95aef, "__pm_runtime_disable" },
	{ 0x4292a372, "debugfs_create_dir" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0x99fb7e2d, "pci_free_irq_vectors" },
	{ 0xed24333b, "pci_enable_sriov" },
	{ 0x2e5b7c32, "__pm_runtime_idle" },
	{ 0x858c69be, "cdev_init" },
	{ 0xe2c17b5d, "__SCT__might_resched" },
	{ 0x8da0819, "kmalloc_caches" },
	{ 0xab10a1d7, "vchan_find_desc" },
	{ 0xc892ac3e, "cdev_del" },
	{ 0x1a0d771, "kmem_cache_destroy" },
	{ 0xc4f1d4ce, "vchan_tx_submit" },
	{ 0x72bc5090, "dma_map_sg_attrs" },
	{ 0xe2fd41e5, "module_layout" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("pci:v00001FF4d00000000sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00001FF4d00000001sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "EBD7483CAE477831CF40299");
