#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/export-internal.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

#ifdef CONFIG_UNWINDER_ORC
#include <asm/orc_header.h>
ORC_HEADER;
#endif

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xe3ec2f2b, "alloc_chrdev_region" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0xad0bf482, "dx_sgdma_deinit" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0xd545a0fc, "dx_pcie_get_message_area" },
	{ 0x92540fbf, "finish_wait" },
	{ 0x75646747, "class_destroy" },
	{ 0x7d628444, "memcpy_fromio" },
	{ 0xe1e7a493, "dx_pcie_get_booting_region" },
	{ 0x37a0cba, "kfree" },
	{ 0x39e7916b, "dx_pcie_clear_response_queue" },
	{ 0x44be8471, "pcpu_hot" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0xe2964344, "__wake_up" },
	{ 0x2699c5f1, "dx_pcie_is_response_queue_empty" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x269ac578, "dx_pcie_enqueue_event_response" },
	{ 0x65487097, "__x86_indirect_thunk_rax" },
	{ 0xb9e7429c, "memcpy_toio" },
	{ 0x122c3a7e, "_printk" },
	{ 0x1000e51, "schedule" },
	{ 0x2ec2012f, "dx_pcie_notify_msg_to_device" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x3d26254e, "dx_pcie_interrupt_clear" },
	{ 0x87a21cb3, "__ubsan_handle_out_of_bounds" },
	{ 0x6b732375, "cdev_add" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0x3b69de06, "device_create" },
	{ 0x6ca9b86a, "class_create" },
	{ 0x4c03a563, "random_kmalloc_seed" },
	{ 0x4dfa8d4b, "mutex_lock" },
	{ 0xac5bfa41, "dma_alloc_attrs" },
	{ 0xfda406b8, "dx_pcie_get_dl_area" },
	{ 0x9a3c9869, "dx_sgdma_read" },
	{ 0xe4cb9af1, "dx_pcie_interrupt_wakeup" },
	{ 0x9f6c145f, "dx_pcie_get_download_size" },
	{ 0x98ff5b35, "dx_pcie_interrupt_event_wakeup" },
	{ 0x799c15a5, "dx_pcie_get_dev_num" },
	{ 0x2ef1b23, "kthread_stop" },
	{ 0xcefb0c9f, "__mutex_init" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x4e28dccd, "dx_sgdma_write" },
	{ 0x6106b455, "dx_pcie_dequeue_response" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0x96375987, "dx_pcie_get_download_region" },
	{ 0x9f3bd1c3, "dma_free_attrs" },
	{ 0x6091b333, "unregister_chrdev_region" },
	{ 0x3213f038, "mutex_unlock" },
	{ 0x8134286, "dx_pcie_dequeue_event_response" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0xe8765b54, "dx_pcie_get_log_area" },
	{ 0x5b40b481, "device_destroy" },
	{ 0x2cf56265, "__dynamic_pr_debug" },
	{ 0x91193f38, "dx_pcie_notify_req_to_device" },
	{ 0xba2484cc, "dma_mmap_attrs" },
	{ 0x1ccbceca, "dx_pcie_set_init_completed" },
	{ 0xd0c3484c, "kmalloc_trace" },
	{ 0xdf4fad68, "dx_pcie_get_driver_info" },
	{ 0x63be5207, "dx_pcie_get_init_completed" },
	{ 0x9b9ef2b1, "dx_pcie_get_request_queue" },
	{ 0x9d9d70e6, "dx_sgdma_init" },
	{ 0xb5b54b34, "_raw_spin_unlock" },
	{ 0x645da062, "dx_pcie_interrupt" },
	{ 0x858c69be, "cdev_init" },
	{ 0xe2c17b5d, "__SCT__might_resched" },
	{ 0x8da0819, "kmalloc_caches" },
	{ 0xc892ac3e, "cdev_del" },
	{ 0xe2fd41e5, "module_layout" },
};

MODULE_INFO(depends, "dx_dma");


MODULE_INFO(srcversion, "74BF201CE179BB1728CB212");
