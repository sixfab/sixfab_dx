# DMA Graceful Stop on Ctrl+C (SIGINT)

## 1. 개요

DMA 전송 중 사용자가 Ctrl+C를 입력하면 SIGINT가 프로세스에 전달됩니다.
커널 DMA thread는 현재 진행 중인 Linked-List chunk의 완료를 기다린 후 **안전하게
종료**합니다. HW의 doorbell stop은 Linked-List 모드에서 동작하지 않으므로,
upstream Linux 커널(torvalds/linux)과 동일한 **EDMA_REQ_STOP** 방식을 사용합니다.

### 핵심 원칙

- 현재 HW가 처리 중인 LL chunk는 **끝까지 완료시킴** (데이터 정합성 보장)
- 다음 chunk는 **시작하지 않음** (불필요한 전송 방지)
- 일정 시간 내 완료되지 않으면 **engine_en cycle로 HW를 강제 리셋**

## 2. 전체 흐름 (Sequence Diagram)

```
  User Process          Kernel DMA Thread         Done ISR            HW eDMA
  ──────────           ─────────────────         ────────            ────────
       │                      │                      │                  │
  Ctrl+C (SIGINT)             │                      │                  │
       │                      │                      │                  │
       ├──SIGINT──────────────>                      │                  │
       │                      │                      │                  │
       │              [ERESTARTSYS 반환]              │                  │
       │                      │                      │                  │
       │              dmaengine_terminate_all()       │                  │
       │              ┌───────┘                       │                  │
       │              │ chan->request = EDMA_REQ_STOP  │                  │
       │              └───────┐                       │                  │
       │                      │                      │                  │
       │              wait_event_timeout()            │          [LL chunk 완료]
       │              (non-interruptible)             │                  │
       │                      │                      │            MSI 발생
       │                      │                      ◄──────────────────┤
       │                      │                      │                  │
       │                      │         [request == EDMA_REQ_STOP]      │
       │                      │         → 다음 chunk 시작 안함          │
       │                      │         → vchan_cookie_complete()       │
       │                      │         → callback()                    │
       │                      │              │                          │
       │                      │              ├─ done->done = true       │
       │                      │              └─ wake_up()               │
       │                      │                      │                  │
       │              [wake up!]                      │                  │
       │              cb->result = 0                  │                  │
       │                      │                      │                  │
       │              return to user-space            │                  │
       │                      │                      │                  │
```

## 3. 상세 구현

### 3.1 단계 1: Signal 수신 (dw-edma-thread.c)

DMA thread는 `wait_event_interruptible_timeout()`으로 전송 완료를 대기합니다.
SIGINT 발생 시 이 함수는 **-ERESTARTSYS**를 반환합니다.

```c
/* DMA 전송 시작 후 완료 대기 */
ret = wait_event_interruptible_timeout(info->done_wait,
        done->done || dw_chan->hw_err,
        msecs_to_jiffies(timeout));
```

> **핵심**: `interruptible` 대기이므로 signal이 깨울 수 있습니다.

### 3.2 단계 2: Graceful Stop 요청 (dw-edma-thread.c → dw-edma-core.c)

`ret == -ERESTARTSYS` 감지 시, `dmaengine_terminate_all()`을 호출합니다.

```c
if (ret == -ERESTARTSYS) {
    dev_info(dev, "%s: signal received, requesting graceful DMA stop\n",
             dma_chan_name(chan));
    dmaengine_terminate_all(chan);  // → terminate_all() → EDMA_REQ_STOP 설정
    ...
}
```

**terminate_all 내부 (첫 번째 호출):**

```c
/* dw_edma_device_terminate_all() - 채널이 BUSY이고 STOP 미설정 시 */
chan->request = EDMA_REQ_STOP;
/* HW에 직접적인 정지 명령 없음 — flag만 설정 */
```

> **왜 doorbell stop을 사용하지 않는가?**
> Synopsys DW eDMA IP의 doorbell stop (bit 31)은 **Linked-List 모드에서
> 동작하지 않습니다**. Upstream Linux 커널(torvalds/linux)의 dw-edma-core.c도
> 이 방식을 사용하지 않으며, EDMA_REQ_STOP flag 방식을 사용합니다.

### 3.3 단계 3: Non-interruptible Re-wait (dw-edma-thread.c)

Signal 이후 **추가 signal에 의해 다시 깨어나지 않도록** non-interruptible wait으로
전환합니다.

```c
/* Re-wait: 현재 LL chunk 완료를 기다림 */
ret = wait_event_timeout(info->done_wait,       /* ← interruptible 아님! */
        done->done || dw_chan->hw_err,
        msecs_to_jiffies(timeout));
```

> **왜 non-interruptible인가?**
> - 첫 signal로 이미 EDMA_REQ_STOP을 설정함
> - 두 번째 signal이 또 깨우면 불필요한 timeout 경로 진입
> - DMA ISR의 `wake_up()`은 interruptible/non-interruptible 모두 깨울 수 있음

### 3.4 단계 4: Done ISR의 EDMA_REQ_STOP 처리 (dw-edma-core.c)

현재 LL chunk의 HW 전송이 완료되면 MSI 인터럽트가 발생하고, Done ISR이 실행됩니다.

```c
/* dw_edma_done_interrupt() 내부 */
switch (chan->request) {
case EDMA_REQ_STOP:
    /* 다음 chunk를 시작하지 않고 descriptor를 완료 처리 */
    list_del(&vd->node);
    vchan_cookie_complete(vd);       /* → callback → wake_up() */
    chan->request = EDMA_REQ_NONE;
    chan->status = EDMA_ST_IDLE;
    break;

case EDMA_REQ_NONE:
    if (desc->chunks_alloc) {
        /* 정상 경로: 다음 chunk 시작 */
        dw_edma_start_transfer(chan);
    } else {
        /* 모든 chunk 완료 */
        vchan_cookie_complete(vd);
    }
    break;
}
```

> **핵심 동작**: `EDMA_REQ_STOP`이 설정되어 있으면 현재 chunk 완료 후
> `dw_edma_start_transfer()`를 **호출하지 않습니다**.

### 3.5 단계 5: Callback → Thread 깨우기

`vchan_cookie_complete()` → DMA callback 호출 → thread wakeup:

```c
static void dw_edma_callback(void *arg) {
    struct dw_edma_info *info = arg;
    info->dma_done.done = true;
    wake_up(info->dma_done.wait);    /* wait_event_timeout()을 깨움 */
}
```

Thread가 깨어나면 `done->done == true`이므로 정상 종료 경로로 진입합니다:

```c
if (ret == 0 && !done->done) {
    /* timeout → force cleanup */
} else {
    dev_info(dev, "%s: DMA stopped gracefully\n", dma_chan_name(chan));
    cb->result = 0;   /* 성공 */
}
```

## 4. Timeout Fallback (Force Cleanup)

LL chunk 완료가 timeout 내에 이루어지지 않으면 HW가 stuck된 것으로 판단하고
**engine_en cycle**로 강제 리셋합니다.

```
[wait_event_timeout 만료 (ret == 0)]
    │
    ├── dmaengine_terminate_all() ← 두 번째 호출
    │       │
    │       └── chan->request == EDMA_REQ_STOP 이미 설정됨
    │           → "force cleanup" 경로 진입
    │           → engine_en = 0 → udelay(200) → engine_en = 1
    │           → 인터럽트 클리어 (done + abort)
    │           → descriptor list 해제
    │           → chan->status = EDMA_ST_IDLE
    │
    └── cb->result = -ETIMEDOUT
```

**terminate_all 내부 (두 번째 호출):**

```c
} else if (chan->request == EDMA_REQ_STOP) {
    pr_warn("Channel %d: STOP already set, forcing engine reset + cleanup\n",
            chan->id);

    /* engine_en = 0 → 1 : DMA HW state 리셋 */
    dw_edma_v0_core_engine_cycle(chan);

    dw_edma_v0_core_clear_done_int(chan);
    dw_edma_v0_core_clear_abort_int(chan);

    /* Descriptor 목록 해제 */
    spin_lock_irqsave(&vc->lock, flags);
    list_splice_tail_init(&vc->desc_issued, &head);
    spin_unlock_irqrestore(&vc->lock, flags);
    vchan_dma_desc_free_list(vc, &head);

    chan->request = EDMA_REQ_NONE;
    chan->status = EDMA_ST_IDLE;
    chan->configured = false;
}
```

> **WARNING**: `engine_cycle`은 동일 방향(WR 또는 RD)의 **모든 채널**에 영향을
> 줍니다. Multi-process 환경에서 다른 프로세스의 DMA 전송이 동시에 진행 중이면
> 함께 중단됩니다.

## 5. 상태 전이도

```
                          ┌───────────────────────────────┐
                          │                               │
                 (정상)   ▼     Ctrl+C                    │
                ┌───── BUSY ──────────────┐               │
                │  req=NONE               │               │
                │                         ▼               │
                │              BUSY (req=EDMA_REQ_STOP)   │
                │                    │                    │
                │           ┌────────┴────────┐          │
                │           │                 │          │
                │     Done ISR 발생       Timeout 만료   │
                │     (chunk 완료)       (HW stuck)     │
                │           │                 │          │
                │           ▼                 ▼          │
                │     IDLE (req=NONE)   engine_cycle     │
                │     cb->result = 0    + force cleanup  │
                │           │                 │          │
                │           │           IDLE (req=NONE)  │
                │           │           cb->result =     │
                │           │           -ETIMEDOUT       │
                │           │                 │          │
                └───────────┴────────┬────────┘          │
                                     │                   │
                                     ▼                   │
                              [Thread 종료]              │
                              return to user ────────────┘
                              (다음 전송 가능)
```

## 6. Kernel Log 예시

### 정상 Graceful Stop

```
[  120.345] dma0chan0: signal received, requesting graceful DMA stop
[  120.347] dma0chan0: DMA stopped gracefully
```

### Timeout Fallback

```
[  120.345] dma0chan0: signal received, requesting graceful DMA stop
[  128.345] dma0chan0: graceful stop timed out, forcing cleanup
[  128.345] Channel 0: STOP already set, forcing engine reset + cleanup
[  128.345] CH0 WR: engine_en cycle (force reset)
```

## 7. 관련 파일

| 파일 | 역할 |
|------|------|
| `dw-edma-thread.c` | DMA transfer thread. Signal 감지, re-wait, callback 처리 |
| `dw-edma-core.c` | `terminate_all()`: EDMA_REQ_STOP 설정 / force cleanup.<br>`done_interrupt()`: ISR에서 STOP flag 확인 후 다음 chunk skip |
| `dw-edma-v0-core.c` | `engine_cycle()`: HW engine_en 레지스터 리셋 (force cleanup) |

## 8. Design Decision 요약

| 결정 | 이유 |
|------|------|
| Doorbell stop 미사용 | DW eDMA LL mode에서 동작하지 않음. Upstream도 미사용. |
| EDMA_REQ_STOP flag 방식 | Upstream Linux kernel과 동일한 접근 방식 |
| Re-wait을 non-interruptible로 | 중복 signal에 의한 불필요한 timeout 방지 |
| `wake_up()` 사용 (not `wake_up_interruptible()`) | Non-interruptible re-wait도 깨울 수 있어야 함 |
| FW 통보 없음 | Remote DMA는 FW Local 레지스터로 제어 불가 |
| Timeout 시 engine_cycle | 최후 수단으로 HW 상태 강제 리셋. 동일 방향 전 채널 영향. |
