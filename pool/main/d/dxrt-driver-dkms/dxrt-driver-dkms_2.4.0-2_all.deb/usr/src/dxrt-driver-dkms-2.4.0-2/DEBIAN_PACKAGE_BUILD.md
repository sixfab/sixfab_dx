# Debian Package Build Process

DeepX NPU Driver DKMS 패키지 빌드 및 배포를 위한 프로세스 가이드입니다.

## Overview

- **Package Name**: `dxrt-driver-dkms`
- **Package Type**: DKMS (Dynamic Kernel Module Support)
- **Build Tool**: `dpkg-buildpackage`
- **Version Source**: `release.ver` file
- **Output Location**: `release/${VERSION}/`

## Directory Structure

```
dx_rt_npu_linux_driver/
├── release.ver                          # Version source (e.g., "v2.1.0")
├── debian/                              # Debian package configuration
│   ├── changelog                        # Package changelog (MUST UPDATE)
│   ├── control                          # Package metadata
│   ├── rules                            # Build rules
│   ├── compat                           # Debhelper compatibility level
│   ├── dxrt-driver-dkms.install         # File installation rules
│   ├── postinst                         # Post-installation script
│   └── prerm                            # Pre-removal script
├── dkms.conf                            # DKMS configuration
├── modules/                             # Source code
│   ├── build.sh                         # Build wrapper script
│   └── scripts/
│       └── debian_builder.sh            # Debian build functions
└── release/                             # Built packages
    ├── 2.1.0/
    │   └── dxrt-driver-dkms_2.1.0-2_all.deb
    └── latest -> 2.1.0/
```

## Build Process Flow

```
1. Read version from release.ver
2. Validate debian/changelog
3. Run dpkg-buildpackage
4. Move .deb to release/${VERSION}/
5. Update 'latest' symlink
6. Cleanup build artifacts
```

## Prerequisites

### System Requirements

```bash
# Ubuntu/Debian
sudo apt-get install -y \
    dpkg-dev \
    debhelper \
    dkms \
    build-essential

# Check versions
dpkg-buildpackage --version
dkms --version
```

### File Checklist

Before building, ensure these files are properly configured:

- [ ] `release.ver` - Contains correct version (e.g., `v2.1.0`)
- [ ] `debian/changelog` - Updated with new version entry
- [ ] `debian/control` - Correct maintainer and dependencies
- [ ] `dkms.conf` - Correct PACKAGE_VERSION

## Manual Build Steps

### Step 1: Update Version

Edit `release.ver`:
```bash
echo "v2.1.0" > release.ver
```

### Step 2: Update Changelog

**CRITICAL**: `debian/changelog` MUST be updated before every build.

#### Format:
```
dxrt-driver-dkms (VERSION-REVISION) DISTRIBUTION; urgency=URGENCY

  * Change description line 1
  * Change description line 2

 -- Maintainer Name <email@example.com>  DATE
```

#### Example:
```bash
# Edit debian/changelog
vim debian/changelog
```

Add new entry at the TOP:
```
dxrt-driver-dkms (2.1.0-2) unstable; urgency=medium

  * Add sleep/resched in dxrt_polling_ack to avoid soft lockups
  * Optimized PCIe DMA performance
  * Compatible with DX-RT SDK v3.2.1+

 -- An Taegyun <atg@deepx.ai>  Mon, 10 Feb 2026 10:00:00 +0900
```

**Date Format**: Use `date -R` to generate RFC 2822 format:
```bash
date -R
# Mon, 10 Feb 2026 10:00:00 +0900
```

### Step 3: Build Package

```bash
cd modules/
./build.sh -c debian-package
```

**Build Output:**
```
*** Building Debian Package ***

-> Checking Debian build prerequisites...
✓ Prerequisites checked
Debian package version: 2.1.0-2
✓ Changelog is up-to-date with version 2.1.0-2
-> Building in: /path/to/dx_rt_npu_linux_driver
-> Running dpkg-buildpackage...
   This may take a few minutes...

✓ Package built successfully
-> Found package: dxrt-driver-dkms_2.1.0-2_all.deb
-> Moving to release/2.1.0/
✓ Package installed to release/2.1.0/
✓ Symlink 'latest' -> 2.1.0
-> Cleaning up build artifacts...
✓ Build artifacts cleaned up

*** Debian Package Build Completed ***

  Package: dxrt-driver-dkms
  Version: 2.1.0-2
  Location: release/2.1.0/
```

### Step 4: Verify Package

```bash
# Check file exists
ls -lh release/2.1.0/dxrt-driver-dkms_2.1.0-2_all.deb

# Inspect package contents
dpkg-deb -c release/2.1.0/dxrt-driver-dkms_2.1.0-2_all.deb

# Check package info
dpkg-deb -I release/2.1.0/dxrt-driver-dkms_2.1.0-2_all.deb
```