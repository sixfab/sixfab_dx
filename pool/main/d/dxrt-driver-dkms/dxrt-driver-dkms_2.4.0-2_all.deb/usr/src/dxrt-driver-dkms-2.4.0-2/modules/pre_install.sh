#!/bin/bash
# Pre-install hook: Only run during automatic kernel updates (not during package updates)
# Check if we're in automatic DKMS mode (not triggered by postinst)

if [ -z "$DKMS_PACKAGE_UPDATE" ]; then
    if systemctl is-active --quiet dxrt 2>/dev/null; then
        systemctl stop dxrt || true
    fi
    if lsmod | grep -q '^dxrt_driver'; then
        rmmod -f dxrt_driver || true
    fi
    if lsmod | grep -q '^dx_dma'; then
        rmmod -f dx_dma || true
    fi
fi
