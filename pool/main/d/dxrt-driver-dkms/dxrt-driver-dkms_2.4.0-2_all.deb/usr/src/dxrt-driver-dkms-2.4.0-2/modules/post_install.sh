#!/bin/bash
# Post-install hook: Only run during automatic kernel updates
# Start service if it's enabled (system wants it to run automatically)

# Dynamically resolve target kernel version (rpi-2712 build)
KERNEL_VER=$(ls /lib/modules | grep rpi-2712 | head -n 1)

if [ -z "$KERNEL_VER" ]; then
    echo "WARNING: No rpi-2712 kernel found in /lib/modules, skipping module load." >&2
    exit 0
fi

if [ -z "$DKMS_PACKAGE_UPDATE" ]; then
    modprobe -S "$KERNEL_VER" dx_dma || true
    modprobe -S "$KERNEL_VER" dxrt_driver || true
    if systemctl is-enabled --quiet dxrt 2>/dev/null; then
        systemctl start dxrt || true
    fi
fi
