#!/bin/bash
# Post-install hook: Only run during automatic kernel updates
# Start service if it's enabled (system wants it to run automatically)

if [ -z "$DKMS_PACKAGE_UPDATE" ]; then
    modprobe dx_dma || true
    modprobe dxrt_driver || true
    if systemctl is-enabled --quiet dxrt 2>/dev/null; then
        systemctl start dxrt || true
    fi
fi
