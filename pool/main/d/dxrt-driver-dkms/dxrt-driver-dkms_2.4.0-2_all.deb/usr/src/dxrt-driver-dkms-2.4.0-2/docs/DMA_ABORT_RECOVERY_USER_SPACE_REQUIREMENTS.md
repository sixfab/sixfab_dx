# DMA Abort Recovery — User-Space 구현 요구사항

## 1. 개요

DMA 에러 발생 시 driver는 에러 유형에 따라 2단계로 처리합니다:

1. **Soft Reset 시도** (driver 내부): Timeout + CS=2 상태에서 driver가 자체적으로
   `engine_en` cycle을 수행하여 HW 복구를 시도합니다. 성공 시 해당 채널은 즉시
   재사용 가능하며, **user-space에 이벤트를 전달하지 않습니다.**

2. **User-space Recovery 위임**: Soft reset 실패 시, 또는 Abort MSI를 받은 경우
   driver는 event_queue를 통해 user-space에 에러 이벤트를 전달합니다.
   User-space는 이 이벤트를 수신하여 적절한 recovery 절차를 수행해야 합니다.

### 에러 유형별 처리 요약

| 에러 유형 | Driver 내부 처리 | User-space Event |
|-----------|------------------|------------------|
| Timeout + CS=2 (soft reset 성공) | `engine_en` cycle → CS=0 복구 | **없음** (채널 재사용 가능) |
| Timeout + CS=2 (soft reset 실패) | `engine_en` cycle 시도 → CS 여전히 2 | `ERR_PCIE_DMA_CHx_FAIL` (100+ch) |
| Timeout + CS≠2 (채널 stuck) | `EDMA_REQ_STOP`만 설정 | `ERR_PCIE_DMA_CHx_FAIL` (100+ch) |
| Abort MSI (HW abort interrupt) | per-channel 에러 인지 + descriptor 완료 | `ERR_PCIE_DMA_CHx_ABORT` (400+ch) |

### 아키텍처 흐름 — Timeout + CS=2 (Driver 내부 복구)

```
[DMA Timeout] → [CS=2 감지]
    → dmaengine_terminate_all() × 2
        → 1st: EDMA_REQ_STOP 설정
        → 2nd: ch_soft_reset (err_status RC 읽기 + engine_en cycle)
    → CS 재확인
    → CS=0/3 → 복구 성공 → -EIO 반환 (user-space event 없음)
    → CS=2   → 복구 실패 → -EIO 반환 + user-space event 전송
```

> **주의**: `engine_en` cycle은 같은 방향(WR 또는 RD)의 **모든 채널**을 리셋합니다.
> CS bits [6:5]는 read-only HW status이며, per-channel-only HW 복구 수단은 없습니다.

### 아키텍처 흐름 — Abort MSI (HW Interrupt)

```
[HW Abort] → [MSI IRQ] → [Driver abort ISR]
    → per-channel 에러 인지 (err_status 읽기, 인터럽트 클리어)
    → chan->aborted = true
    → DMA descriptor 완료 처리
    → event_queue에 enriched abort event 삽입
    → RT module → event_wq wake
    → [User-space event thread] DXRT_CMD_EVENT_V2 ioctl 반환
    → User-space에서 recovery 판단
    → [User-space] DXRT_CMD_RECOVERY ioctl 호출
    → Driver: DMA 채널 전체 리셋 + (필요시 PCIe SBR)
    → FW 통보 → 정상 운영 재개
```

## 2. Driver에서 제공하는 인터페이스

### 2.1 Abort Event (DXRT_CMD_EVENT_V2)

Event thread가 `DXRT_CMD_EVENT_V2` ioctl로 대기 중일 때, DMA abort 발생 시 다음
데이터가 반환됩니다:

```c
typedef struct {
    uint32_t            event_type;   /* == DXRT_EVENT_ERROR (1) */
    union {
        dx_pcie_dev_err_t   dx_rt_err;
        /* ... */
    };
} dx_pcie_dev_event_t;
```

**dx_rt_err 주요 필드:**

| 필드               | 타입          | 설명 |
|--------------------|---------------|------|
| `err_code`         | `uint32_t`    | 에러 코드. DMA abort: `400 + channel_id` (0-based) |
| `dma_err`          | `uint32_t`    | HW `err_status` 레지스터 값 (abort 원인 진단용) |
| `dma_wr_ch_sts[4]` | `uint32_t[]` | Write 채널 0~3의 CS(Channel Status) 값 |
| `dma_rd_ch_sts[4]` | `uint32_t[]` | Read 채널 0~3의 CS(Channel Status) 값 |
| `bus`, `dev`, `func` | PCIe BDF   | 장치 식별 정보 (RT module에서 채움) |
| `rt_driver_version` | `uint32_t`  | RT driver 버전 |
| `pcie_driver_version` | `uint32_t` | PCIe driver 버전 |

**err_code 값 해석:**

| 범위      | 의미 | 발생 조건 |
|-----------|------|-----------|
| 100–103   | `ERR_PCIE_DMA_CHx_FAIL` — DMA timeout 후 soft reset 실패, 또는 CS≠2 stuck | Timeout + soft reset 실패 |
| 200–201   | `ERR_LPDDR_DED_WR/RD` — LPDDR ECC 에러 | FW에서 보고 |
| 300       | `ERR_FW_TIMEOUT` — Firmware 응답 타임아웃 | FW 무응답 |
| 400–403   | `ERR_PCIE_DMA_CHx_ABORT` — DMA HW abort interrupt | Abort MSI 수신 |

> **Note**: Timeout + CS=2에서 soft reset이 **성공**한 경우에는 event가 발생하지 않습니다.
> User-space DMA 호출은 -EIO를 반환하므로 단순히 재시도하면 됩니다.

**dma_err (err_status 레지스터) 해석:**

DW eDMA v0 err_status 레지스터의 Read-Clear 값입니다. Bit 필드 정의는
Synopsys DW eDMA Databook의 `wr_err_status` / `rd_err_status` 섹션을 참고하세요.
값이 0이면 abort ISR 시점에 채널이 이미 error state가 아니었음을 의미합니다.

**Channel Status (CS) 값 해석:**

| CS 값 | 상태 | 설명 |
|--------|------|------|
| 0      | Reserved | - |
| 1      | Running  | 정상 동작 중 |
| 2      | Halted/Error | Abort 등으로 정지됨 (recovery 필요) |
| 3      | Stopped  | 정상 정지 (idle) |

## 3. User-Space 구현 요구사항

### 3.1 Event Listener Thread

**필수 구현:**

1. 전용 event listener thread를 1개 유지합니다.
2. `DXRT_CMD_EVENT_V2` ioctl로 blocking 대기합니다.
3. ioctl 반환 시 `event_type`을 확인합니다.

```c
// Pseudo-code
void *event_listener_thread(void *arg) {
    dxrt_message_t msg;
    dx_pcie_dev_event_t event;

    while (!shutdown) {
        msg.cmd = DXRT_CMD_EVENT_V2;
        msg.data = &event;

        int ret = ioctl(fd, DXRT_IOCTL, &msg);
        if (ret < 0) {
            if (errno == ECANCELED)
                break;  // Device closing
            if (errno == ERESTARTSYS)
                continue;  // Signal interrupted, retry
            // Handle error
            continue;
        }

        switch (event.event_type) {
        case DXRT_EVENT_ERROR:
            handle_dma_error(&event.dx_rt_err);
            break;
        case DXRT_EVENT_PROC_EXIT:
            handle_proc_exit(&event.dx_rt_proc_exit);
            break;
        case DXRT_EVENT_NOTIFY_THROT:
            handle_throttle_notify(&event.dx_rt_ntfy_throt);
            break;
        default:
            break;
        }
    }
    return NULL;
}
```

### 3.2 DMA Abort Error Handler

**필수 구현:**

```c
void handle_dma_error(const dx_pcie_dev_err_t *err) {
    int err_code = err->err_code;

    // 1. 어떤 종류의 에러인지 판별
    if (err_code >= 400 && err_code < 500) {
        // DMA Abort (HW abort MSI)
        int abort_ch = err_code - 400;
        log_abort_diagnostics(abort_ch, err);
        trigger_recovery();
    } else if (err_code >= 100 && err_code < 200) {
        // DMA Soft Reset Failure (timeout + CS=2 + engine_en cycle 실패)
        // driver가 engine_en cycle을 시도했으나 CS가 여전히 2인 상태.
        // Full recovery가 필요합니다 (PCIe SBR 포함 가능).
        int fail_ch = err_code - 100;
        log_dma_failure(fail_ch, err);
        trigger_recovery();
    } else if (err_code == 300) {
        // FW Timeout
        log_fw_timeout(err);
        trigger_recovery();
    }
}
```

> **Important**: `err_code` 100번대 이벤트를 수신했다면 driver 내부의 soft reset이
> **실패**한 것입니다. `engine_en` cycle로도 CS=2가 해소되지 않은 상태이므로,
> `DXRT_CMD_RECOVERY` (full recovery, PCIe SBR 포함)가 필요합니다.

### 3.3 Recovery 절차

**필수 구현:**

Recovery는 `DXRT_CMD_RECOVERY` ioctl을 통해 수행합니다.

```c
void trigger_recovery(void) {
    dxrt_message_t msg;

    // 1. 진행 중인 모든 inference 작업 중단
    //    (다른 thread들에게 recovery 시작 알림)
    set_recovery_flag(true);

    // 2. 진행 중인 DMA 전송 완료 대기 (타임아웃 포함)
    //    Driver가 abort된 채널의 in-flight 전송을 -EIO로 완료시키므로,
    //    user-space DMA thread들이 에러 반환을 받을 때까지 대기합니다.
    wait_for_inflight_dma_completion(RECOVERY_WAIT_TIMEOUT_MS);

    // 3. RECOVERY ioctl 호출
    msg.cmd = DXRT_CMD_RECOVERY;
    msg.data = NULL;
    int ret = ioctl(fd, DXRT_IOCTL, &msg);
    if (ret < 0) {
        log_error("Recovery failed: %s", strerror(errno));
        // 최후 수단: 장치 재초기화 또는 프로세스 종료
        return;
    }

    // 4. Recovery 완료 후 상태 정리
    reset_dma_channel_state();
    set_recovery_flag(false);

    // 5. 정상 운영 재개
    //    Model re-load가 필요할 수 있음 (DDR 내용이 SBR로 소실될 수 있음)
    reload_models_if_needed();
}
```

### 3.4 Diagnostic Logging

**필수 구현:**

Abort 이벤트 수신 시 다음 정보를 로그에 기록합니다:

```c
void log_abort_diagnostics(int abort_ch, const dx_pcie_dev_err_t *err) {
    printf("[DMA ABORT] Channel %d\n", abort_ch);
    printf("  err_status=0x%08x\n", err->dma_err);
    printf("  WR ch status: [%u, %u, %u, %u]\n",
           err->dma_wr_ch_sts[0], err->dma_wr_ch_sts[1],
           err->dma_wr_ch_sts[2], err->dma_wr_ch_sts[3]);
    printf("  RD ch status: [%u, %u, %u, %u]\n",
           err->dma_rd_ch_sts[0], err->dma_rd_ch_sts[1],
           err->dma_rd_ch_sts[2], err->dma_rd_ch_sts[3]);
    printf("  PCIe BDF: %02x:%02x.%x\n",
           err->bus, err->dev, err->func);
}
```

## 4. Multi-Process 환경 고려사항

### 4.1 채널 독립성

- DMA abort은 **per-channel** 이벤트이지만, HW 복구는 per-channel 단위로 불가능합니다.
- **CS bits [6:5]는 read-only HW status**이므로, CS=2를 클리어하려면 반드시
  `engine_en=0→1` cycle이 필요합니다.
- `engine_en` cycle은 같은 방향(WR 또는 RD)의 **모든 채널**을 리셋합니다.
- Timeout + CS=2 시 driver가 자동으로 soft reset을 시도하며, 성공하면 user-space
  event 없이 해당 채널만 -EIO를 반환합니다. 단, 같은 방향의 다른 채널이 전송 중이었다면
  그 전송도 실패할 수 있습니다.

### 4.2 Recovery 조율

| 항목 | 설명 |
|------|------|
| **단일 recovery 주체** | Recovery ioctl은 한 프로세스만 호출해야 합니다. `recovery_epoch` (atomic counter)를 통해 중복 recovery를 감지할 수 있습니다. |
| **다른 프로세스 알림** | Recovery 중 다른 프로세스의 `DXRT_CMD_EVENT_V2`는 blocking 상태를 유지하며, recovery 완료 후 자동으로 wake됩니다. |
| **Response 대기 중인 thread** | Recovery 시 driver가 모든 response waitqueue를 wake합니다. 대기 중인 thread들은 에러를 받게 됩니다. |

### 4.3 Recovery 후 상태

Recovery (`DXRT_CMD_RECOVERY`) 완료 후:

1. **모든 DMA 채널**이 CS=3 (Stopped) 상태로 복귀
2. **Event queue** 초기화 (stale event 제거)
3. **Response queue** 초기화
4. **FW 통보 완료** (FW도 recovery 상태 정리)
5. PCIe SBR이 수행된 경우 **DDR 내용이 소실**될 수 있으므로 model reload 필요

## 5. 에러 처리 Flow Chart

```
Event Thread이 DXRT_EVENT_ERROR 수신
    │
    ├── err_code >= 200 (DMA Abort)?
    │   ├── YES → log diagnostics from enriched event
    │   │         → notify all worker threads to stop
    │   │         → wait for in-flight DMA to drain
    │   │         → call DXRT_CMD_RECOVERY ioctl
    │   │         → on success: reload models, resume
    │   │         → on failure: fatal error, restart process
    │   │
    │   └── NO  → err_code >= 100 (DMA Fail)?
    │       ├── YES → same as abort flow
    │       └── NO  → err_code == 300 (FW Timeout)?
    │           ├── YES → same as abort flow
    │           └── NO  → unknown error, log and skip
    │
    └── err_code == 0 (FW event via shared memory)?
        → FW에서 shared memory로 전달한 이벤트
        → event_type에 따라 처리
```

## 6. 주의사항

1. **Recovery는 blocking 호출**입니다. Event listener thread에서 직접 호출하면
   다음 이벤트를 수신할 수 없으므로, 별도 thread에서 호출하거나 비동기로 dispatch하세요.

2. **PCIe SBR (Secondary Bus Reset)** 이 수행되면 endpoint의 모든 상태가 초기화됩니다.
   DMA 채널뿐 아니라 FW 상태, DDR 내용까지 영향받을 수 있습니다.

3. **Timeout + CS=2 시 driver가 먼저 soft reset을 시도합니다.**
   - Soft reset 성공 (CS=0/3) → 채널은 즉시 재사용 가능. **User-space event 없음.**
     DMA 호출은 -EIO를 반환하므로, user-space는 단순히 재시도(retry)하면 됩니다.
   - Soft reset 실패 (CS=2 지속) → `ERR_PCIE_DMA_CHx_FAIL` event가 user-space에
     전달됩니다. 이 경우 `DXRT_CMD_RECOVERY` ioctl을 통한 full recovery가 필요합니다.
   - **주의**: `engine_en` cycle은 같은 방향(WR/RD)의 모든 채널에 영향을 줍니다.
     동일 방향의 다른 채널이 전송 중이었다면 해당 전송도 실패합니다.

4. **Abort MSI 후 해당 채널은 CS=2 (Error) 상태**입니다 (driver가 ch_control1을
   clear합니다). Recovery 없이 새 전송을 시작하면 doorbell이 무시됩니다.
   반드시 recovery를 먼저 수행하세요.

5. **HW 제약: PCIe completion error는 Abort MSI를 발생시키지 않습니다.**
   잘못된 주소로 DMA 전송 시 채널은 CS=2로 정지하지만, Abort MSI는 발생하지 않습니다.
   이 경우 timeout이 만료된 후 driver가 CS=2를 감지하여 soft reset을 시도합니다.
   결과적으로 timeout 시간(기본 3초)만큼 지연됩니다.

6. **Recovery epoch**: Driver는 `recovery_epoch` atomic counter를 증가시킵니다.
   User-space에서 이 값을 추적하면 중복 recovery를 방지할 수 있습니다.

7. **Event queue 크기**: 8개 slot (`DX_EVENT_QUEUE_SIZE`). Abort가 연속으로 발생하면
   queue가 가득 찰 수 있습니다. Event thread가 빠르게 소비하지 않으면 이벤트가
   drop됩니다.
