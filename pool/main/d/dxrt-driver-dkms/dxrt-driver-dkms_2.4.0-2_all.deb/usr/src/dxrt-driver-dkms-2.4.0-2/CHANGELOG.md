# Changelog
### Do not edit. This document is generated automatically.
## [1.7.1] - 2025-07-16

### Fixes

- fix device identification error

### Documentation

- update RELEASE_NOTES.md

### Miscellaneous Tasks

- save material for RELEASE_NOTES after pr merged
- update debian changelog for version 1.7.1-1 release
- save material for RELEASE_NOTES after pr merged

## [1.7.0] - 2025-07-07

### Features

- *(pcie)* add cmd for getting pcie status

### Miscellaneous Tasks

- change bump version to occur on main
- modify dev to main script
- change release notes automation occur on main
- fix variable name for release notes
- fix bump version main
- Create DKMS Debian package for driver
- update .gitignore
- remove legacy-installed .ko files under /lib/modules before DKMS add step
- use rsync instead of git archive and unzip for source export to DKMS_INSTALL_DEST
- save material for RELEASE_NOTES after pr merged
- save material for RELEASE_NOTES after pr merged

## [1.6.0] - 2025-06-13

### Features

- V3 NPU driver added (new)
- V3 NPU driver added (new)
- V3 NPU driver added (new)
- V3 NPU driver added (new)
- V3 NPU driver added (new)

### Documentation

- update RELEASE_NOTES.md

### Miscellaneous Tasks

- fix release notes automation edge case
- modify actions script
- modify release-please.yml
- add submodule update toward dx-runtime
- fix typo error in submodule update

## [1.5.0] - 2025-05-19

### Documentation

- update RELEASE_NOTES.md

### Miscellaneous Tasks

- automated release-excluded & modify convention checker
- add release-excluded automation
- add sonar analysis on pull request
- remove unnecessary install in draft release action
- release notes until latest release tag
- sync pcie deepx driver

## [1.4.3] - 2025-05-12

### Fixes

- *(sgdma)* solve kernel panic cause of contiguous memory allocation fail

### Documentation

- update RELEASE_NOTES.md

### Miscellaneous Tasks

- modify release-excluded
- modify cppcheck report

## [1.4.2] - 2025-05-10

### Refactor

- Remove unused code

### Miscellaneous Tasks

- add cppcheck test on pull request
- add merge conflict test action
- add sonar analysis on pull request
- update change log

## [1.4.1] - 2025-04-22

### Miscellaneous Tasks

- update change log
- public-release to use commit hash as input
- fix dma transation Fail
- checkout submodule for internal repo on release-please.yml
- trivial change on release notes automation

## [1.4.0] - 2025-03-13

### Miscellaneous Tasks

- add RELEASE_NOTES.md automation & modify bump-version trigger condition
- release notes automation fix
- modify release notes template to add jira ticket number
- handle release notes automation exceptions
- modify release notes automation

## [1.3.2] - 2025-02-12

### Refactor

- update resume function for power management

### Miscellaneous Tasks

- Add ddr bandwidth info into response data
- Add ddr bandwidth info into response data
- implement auto recovery
- DNDO-1750 fix dev-to-main workflow
- DNDO-1750 fix dev-to-main workflow ~2
- skip invalid tags for getting next version (bump version github workflow)
- modify CHANGELOG.md & RELEASE_NOTES.md filename
- add message handler for changing device lpddr target freq

## [1.3.1] - 2024-12-20

### Fixes

- fix unknown return type of request_acc func

### Documentation

- update change log

## [1.3.0] - 2024-12-20

### Features

- device error interrupt -> device event(error, notify_throt) interrupt

### Documentation

- update change log

### Miscellaneous Tasks

- sync up submodules
- implement recovery concept
- update device max num(64)
- update release-please.yml
- wake-up logic only applies to event path
- *(release)* fix author to dci for new commit
- add message handler for fw config update

## [1.1.0] - 2024-11-01

### Features

- update multi-process driver

### Miscellaneous Tasks

- update pci_deepx hash to latest dev
- update channel selection for dma read/write
- add github cloud token & url
- include pci_deepx release.ver to pub

## [1.0.13] - 2024-10-29

### Miscellaneous Tasks

- add debian package configuration
- add modprobe for debian package
- update package version to 1.0.7
- update build package version
- update debian rules for compatible
- update pci_deepx hash cause of hash change
- update debian/changelog
- fix build error when installing debian pakcage
- update bounding logic
- update revision mechanism to support new memory map
- update firmware update command(default:device reset)
- add pcie driver verion
- change domain & settings to ghes

## [1.0.12] - 2024-10-15

### Refactor

- Implementation of multiple command modes(ioctl)

## [1.0.11] - 2024-10-15

### Refactor

- Update lock mechanism for queue

### Miscellaneous Tasks

- Add npu request/response commands
- fix compile error

## [1.0.10] - 2024-10-15

### Fixes

- fix queue synchronous problem with device

### Miscellaneous Tasks

- Remove duplication logic for queue full checking

## [1.0.9] - 2024-10-15

### Refactor

- add npu bounding rule

## [1.0.8] - 2024-10-15

### Fixes

- update firmware upload mode

### Miscellaneous Tasks

- update build parameter(device) of asic
- change driver install method and update check-condition
- sync with submoudle

## [1.0.7] - 2024-10-15

### Fixes

- Fix compiler error(v6.6.40)

### Documentation

- update change log

### Miscellaneous Tasks

- add release excluded

## [1.0.6] - 2024-07-22

### Fixes

- Fixed host system hang issue when accessing PCIe

## [1.0.5] - 2024-07-16

### Refactor

- Add inference hybrid-mode for host request

### Miscellaneous Tasks

- update process id into the request message
- update changelog

## [1.0.4] - 2024-07-01

### Refactor

- update scheduler option

### Miscellaneous Tasks

- apply rerun to pr convention check

## [1.0.3] - 2024-06-25

### Refactor

- update interrupt handshake logic for inference

## [1.0.2] - 2024-06-21

### Features

- enable irq mode with device for message/req

### Refactor

- update a device download region

### Miscellaneous Tasks

- fix compile error
- fix spin_lock error and reduce timeout value for identify

### bump-skip

- fix conventoin check logic

## [1.0.1] - 2024-06-10

### Refactor

- update ack polling mode

### Miscellaneous Tasks

- change a commit message check to head and release pattern
- change timeout to 20min

## [1.0.0] - 2024-05-29

### Features

- add public release CI
- add public main tag & release CI
- create release exclude file

### Fixes

- change target branch to avoid overlap branch & tag
- change cmd for getting from/to tag

### Miscellaneous Tasks

- add release.ver
- add LICENSE
- add CHANGELOG.md
- update version to 1.0.0
- add codeowners
- add prefix v on release.ver
- add github actions to check conventions, bump version, and draft release
- fixed syntax error in bump action
- fixed bump permission and set repo checking and timeout
- ignore bump commit and install gh
- fixed install gh
- release excluded a release_notes.md
- bump logic and draft release action for public repo deployment
- fix release-excluded
- apply test script considering official specifications

### build.sh

- Modified to provide the same build options as dx_rt sdk.

### hotfix

- add exclude for utils & pci_xilinx
- change release SDK structure

### npu

- Separate the npu linux driver from the "dx_rt" repository.
- Add subumodules
- Modify code lines and error message.

### pcie

- update init version for m1a

### rt

- Fixed PWD macro that represents the current path.
- Support auto loading boot time
- Add a description of the module installation at README.md
- Check kernel build status before module build

### update

- module insertion script for accelator mode

<!-- generated by git-cliff -->
