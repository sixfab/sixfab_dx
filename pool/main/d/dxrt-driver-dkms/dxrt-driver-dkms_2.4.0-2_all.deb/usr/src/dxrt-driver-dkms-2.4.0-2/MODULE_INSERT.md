# module_insert.sh - Manual Module Loader

Development and testing utility for manually loading/reloading DeepX NPU kernel modules.

## Purpose

This script is designed for development and testing scenarios where you need to:
- Quickly reload modules without reinstalling
- Test local builds without system installation
- Force PCIe re-enumeration for device recovery
- Work with both installed (DKMS/manual) and local builds

## Usage

```bash
sudo ./module_insert.sh [options]
```

## Options

| Option | Description |
|--------|-------------|
| `-m [module]` | Select PCIe module: `deepx` (default) or `xilinx` |
| `-s` | Skip PCIe remove/rescan (use when enumeration not needed) |
| `-h` | Show help message |

## How It Works

The script performs the following steps:

### 1. Uninstall Existing Installation

Automatically detects and removes existing driver installations to ensure local builds are used:

**DKMS Package Installation:**
```bash
# Detected: dpkg -l | grep dxrt-driver-dkms
# Removed:  ./build.sh -c uninstall-package
```

**Manual Installation:**
```bash
# Detected: /lib/modules/$(uname -r)/modules.dep
# Removed:  ./build.sh -c uninstall
```

### 2. Remove Loaded Modules

Unloads currently loaded modules in dependency order:
```bash
rmmod dxrt_driver  # Runtime driver (depends on dx_dma)
rmmod dx_dma       # DMA driver (kills processes if needed)
rmmod virt_dma     # Virtual DMA support
```

If processes are using the driver, they are automatically killed using `fuser` and `lsof`.

### 3. PCIe Re-enumeration (Optional)

Forces PCIe bus to re-detect devices:
```bash
pcie_remove   # Remove upstream PCIe bridges
pcie_rescan   # Trigger bus rescan
```

**Use default (with rescan)** when:
- Device disappeared from `lspci`
- PCIe link errors occurred
- Testing after hardware changes
- First load after boot

**Use `-s` to skip rescan** when:
- Device already visible in `lspci`
- Just updating driver code
- Frequent reload during debugging
- Service restart scenarios
- Want faster reload (saves ~3 seconds)

### 4. Load Modules

Loads modules from **local build directory**:
```bash
modprobe virt_dma                    # Kernel provided
insmod pci_deepx/dx_dma.ko          # Local build
insmod rt/dxrt_driver.ko            # Local build
```

**Important:** Always loads from local build directory, NOT from `/lib/modules/`, ensuring you test the exact code you built.

## Examples

### Standard reload with PCIe rescan (default):
```bash
sudo ./module_insert.sh
```

**Output:**
```
DKMS package detected. Uninstalling via build.sh...rl
Removing dxrt_driver...
Removing dx_dma...
Removing virt_dma...
Finding PCIe devices...
  Found target devices: 01:00.0
Removing upstream PCIe bridges...
Rescanning PCIe bus...
Inserting virt_dma...
** Start loading module from [/path/to/pci_deepx] **
dx_dma loaded successfully!!
** Start loading module from [/path/to/rt] **
dxrt_driver loaded successfully!!
```

### Quick reload without PCIe rescan (faster):
```bash
sudo ./module_insert.sh -s
```

**Output:**
```
Removing dxrt_driver...
Removing dx_dma...
Removing virt_dma...
Skipping PCIe remove/rescan (--skip-rescan option)
Inserting virt_dma...
** Start loading module from [/path/to/pci_deepx] **
dx_dma loaded successfully!!
** Start loading module from [/path/to/rt] **
dxrt_driver loaded successfully!!
```

### Use Xilinx PCIe module:
```bash
sudo ./module_insert.sh -m xilinx
```

### Typical development workflow:
```bash
# Edit code
vim rt/dxrt_drv.c

# Build
./build.sh

# Quick reload (no rescan needed)
sudo ./module_insert.sh -s

# Test
/path/to/test_program
```

## Module Loading Details

### Installed vs Local Modules

This script **always loads local builds** via `insmod`, even if modules are installed to the system:

| Installation Method | Module Location | module_insert.sh Behavior |
|---------------------|-----------------|---------------------------|
| DKMS Package | `/lib/modules/.../updates/dkms/` | Uninstalls, then loads local |
| Manual Install | `/lib/modules/.../extra/` | Uninstalls, then loads local |
| No Installation | N/A | Loads local |

This ensures you're testing the exact build in your working directory.

### Why Uninstall First?

After `pcie_rescan`, the kernel automatically binds drivers:
- If DKMS/manual installed → kernel loads from `/lib/modules/`
- This creates version conflicts (installed ≠ local build)

Solution: Uninstall first, then `insmod` from local directory.

## Notes

- **Root privileges required** - all module operations need `sudo`
- **Development tool only** - production systems should use DKMS or manual installation via `build.sh`
- **PCIe rescan may cause brief device unavailability** - skip with `-s` when not needed
- **Always unload dependent modules first** - dxrt_driver → dx_dma → virt_dma
- **Process termination is automatic** - uses `fuser` and `lsof` to kill processes holding device files
- **DKMS/Manual conflicts handled automatically** - script detects and removes existing installations

## Related Commands

### Build modules:
```bash
./build.sh
```

### Install to system (DKMS):
```bash
./build.sh -c debian-package
sudo ./build.sh -c install-package
```

### Install to system (Manual):
```bash
sudo ./build.sh -c install
```

### Uninstall from system:
```bash
# DKMS
sudo ./build.sh -c uninstall-package

# Manual
sudo ./build.sh -c uninstall
```

### Check DKMS status:
```bash
dkms status dxrt-driver
```

## When to Use This Script

### ✅ Use module_insert.sh when:
- Developing driver code (frequent reload needed)
- Testing local builds before installation
- Debugging PCIe enumeration issues
- Need to force device reset
- Working on multiple driver versions

### ❌ Don't use module_insert.sh for:
- Production deployments (use DKMS package)
- Automatic loading on boot (use systemd + modprobe)
- Systems requiring stability (use manual install via build.sh)

## See Also

- [Build System](build.sh) - Main build script
- [Installation Methods](../README.md) - DKMS vs Manual installation
- [Driver API](include/dxrt_drv.h) - Driver interface documentation
