# SBR Recovery & Multi-Process DMA Race Condition 보호

## 1. 개요

DMA Channel에 Error(CS=2)가 발생하면 driver는 단계적 recovery를 수행합니다:

1. **Per-channel soft reset** — 해당 channel만 `engine_en` cycle로 복구 시도
2. **PCIe SBR (Secondary Bus Reset)** — soft reset 실패 시, endpoint 전체를 HW reset

SBR은 PCIe endpoint의 **모든 HW state**를 초기화하므로, SBR 진행 중에는
모든 DMA channel의 동작이 무의미합니다. 따라서:

- SBR **전에** 모든 DMA channel 동작을 차단
- User-space에 error를 notify
- User-space가 client process를 종료시킨 후 SBR 진행

Multi-process 환경에서는 Process A의 DMA error recovery 중에
Process B가 새로운 DMA transfer를 시도할 수 있기 때문에,
여러 보호 메커니즘이 필요합니다.

---

## 2. Recovery 시퀀스 다이어그램

```
[User-space]                     [dxrt_driver.ko]                  [dx_dma.ko]
     │                                 │                                │
     │  DMA error (CS=2, timeout)      │                                │
     │                                 │                   dw_edma_sg_process()
     │                                 │                   → ERR_PCIE_DMA_CH_FAIL
     │                                 │                     event enqueue ──────┐
     │  ← event reader가 error 수신 ────│────────────────────────────────────────┘
     │                                 │                                │
     │── DXRT_CMD_RECOVERY ioctl ─────→│                                │
     │                    dxrt_recovery_device():                       │
     │                    ① recovering=1, epoch++                      │
     │                    ② clear_queue_list()                         │
     │                    ③ ──────────────────→ dx_pcie_reset_dma_channels():
     │                                 │        ⓐ recovery_epoch++
     │                                 │        ⓑ sbr_in_progress=1
     │                                 │        ⓒ hw_err=true + wake_up (ALL channels)
     │                                 │        ⓓ msleep(1) — thread drain
     │                                 │        ⓔ terminate_all × 2 (ALL channels)
     │                                 │        ⓕ still stuck? → PCIe SBR
     │                                 │        ⓖ ch_in_use reset
     │                                 │        ⓗ sbr_in_progress=0
     │                    ④ clear response/event queues                │
     │                    ⑤ wake response/event waiters                │
     │                    ⑥ FW notify (SBR 시 skip)                    │
     │                    ⑦ recovering=0                               │
     │                                 │                                │
     │  ← recovery 완료, client 재시작 가능                              │
```

---

## 3. 보호 메커니즘 상세

### 3.1 `sbr_in_progress` — DMA Submission 차단 (Admission Gate)

**위치:** `dw-edma-thread.c` → `dw_edma_sg_process()`

```c
/* dw_edma_sg_process() — doorbell 직전 */
if (atomic_read(&dw_chan->chip->dw->sbr_in_progress) ||
    atomic_read(&dw_chan->chip->dw->recovery_epoch) != start_epoch) {
        dev_warn(dev, "%s: recovery/SBR in progress, rejecting transfer\n",
                 dma_chan_name(chan));
        dw_chan->transfer_wq = NULL;
        cb->result = -EIO;
        goto err_stats;
}
```

**목적:**
- Recovery/SBR 진행 중 새로운 DMA transfer의 doorbell ring을 차단
- `sbr_in_progress`가 1이면 HW가 reset 중이므로 doorbell이 의미 없음
- `recovery_epoch`가 변경되었으면 channel state가 이미 변경된 것

**타이밍:**
```
dx_pcie_reset_dma_channels()        dw_edma_sg_process() (Process B)
         │                                    │
  sbr_in_progress=1                   dmaengine_submit() OK
         │                                    │
         │                            ┌── admission gate check ──┐
         │                            │ sbr_in_progress == 1?    │
         │                            │ → YES: return -EIO       │
         │                            └──────────────────────────┘
         │                            (doorbell 호출되지 않음)
```

### 3.2 `recovery_epoch` — Stale Thread 보호

**위치:** `dw-edma-core.h` → `struct dw_edma`

```c
atomic_t recovery_epoch;  /* recovery 마다 increment */
```

**동작:**
1. Transfer 시작 시 `start_epoch = atomic_read(&dw->recovery_epoch)`
2. `wait_event` 후 깨어나면 epoch 재확인
3. Epoch가 변경되었으면 → recovery가 이미 channel을 cleanup했으므로
   `dmaengine_terminate_all()` 호출 없이 즉시 `-EIO` 반환

**중요성:**
Recovery가 완료된 후 새 transfer가 시작된 channel에 대해,
이전 transfer의 stale thread가 `dmaengine_terminate_all()`을 호출하면
새 transfer가 깨지는 문제를 방지합니다.

```
Recovery thread              Stale DMA thread (Process A)     New DMA thread (Process B)
      │                              │                              │
  terminate_all()                    │                              │
  epoch++ (2→3)                      │                              │
      │                          wake_up!                           │
      │                              │                         start transfer
      │                        check epoch:                    epoch=3 capture
      │                        start(2)≠current(3)                  │
      │                        → goto err_stats                 doorbell ring
      │                        (terminate 호출 안함!)               │
      │                              │                         정상 동작
```

### 3.3 `hw_err` + `wake_up` — In-flight Transfer 즉시 종료

**위치:** `dx_sgdma.c` → `dx_pcie_reset_dma_channels()`

```c
for (i = 0; i < dw->wr_ch_cnt + dw->rd_ch_cnt; i++) {
        struct dw_edma_chan *chan = &dw->chan[i];
        chan->hw_err = true;
        if (chan->transfer_wq)
                wake_up_interruptible(chan->transfer_wq);
}
```

**동작:**
- 모든 channel의 `hw_err=true` 설정
- `transfer_wq`가 등록된 channel(= in-flight transfer)의 thread를 즉시 깨움
- 깨어난 thread는 `hw_err` 조건으로 wait_event에서 탈출

**Drain delay:**
```c
msleep(1);  /* thread가 깨어나서 epoch guard까지 도달할 시간 확보 */
```
이후 `terminate_all`을 호출하면 대부분의 channel이 이미 IDLE 상태이므로
깔끔하게 cleanup됩니다.

### 3.4 `vc.lock` in `terminate_all` — State Machine Race 방어

**위치:** `dw-edma-core.c` → `dw_edma_device_terminate_all()`

```c
spin_lock_irqsave(&vc->lock, flags);
/* 전체 state machine (configured, status, request 변경) */
...
spin_unlock_irqrestore(&vc->lock, flags);
```

**목적:**
`terminate_all`이 channel state를 변경하는 동안 `issue_pending()`이
동시에 같은 channel의 state를 읽어서 transfer를 시작하는 race condition 방지.

| Without `vc.lock` | With `vc.lock` |
|---|---|
| terminate: `configured=false` | terminate: lock → `configured=false`, `status=IDLE` → unlock |
| issue_pending: `configured` 읽기 (아직 true) | issue_pending: lock → `configured` 읽기 (false) → unlock |
| → 잘못된 transfer 시작! | → 정상 차단 |

### 3.5 `notify_peer_channels` — engine_en Cycle 피해 통보

**위치:** `dw-edma-v0-core.c`

`ch_soft_reset()` 또는 `engine_cycle()`에서 `engine_en=0→1`을 수행하면
해당 direction(read 또는 write)의 **모든 channel**이 HW적으로 reset됩니다.
이는 DW eDMA HW의 제약사항입니다 (per-channel reset 불가).

```c
static void notify_peer_channels(struct dw_edma_chan *initiator)
{
        /* 같은 direction의 모든 peer channel에 대해 */
        if (peer->status == EDMA_ST_BUSY) {
                peer->hw_err = true;
                if (peer->transfer_wq)
                        wake_up_interruptible(peer->transfer_wq);
        }
}
```

**시나리오:**
```
Channel 0 (WR): CS=2, soft reset 필요
Channel 1 (WR): 정상 transfer 중  ← engine_en cycle에 의해 피해

→ notify_peer_channels()가 Channel 1의 thread를 즉시 깨움
→ Channel 1 thread는 hw_err 감지 → -EIO 반환
→ Timeout까지 기다리지 않고 즉시 실패 통보
```

### 3.6 `recovering` 플래그 — RT Driver 레벨 차단

**위치:** `dxrt_drv_message.c`

| 함수 | 동작 |
|---|---|
| `dxrt_npu_run_request_acc()` | `recovering` 체크 → `-EBUSY` 반환 |
| `dxrt_read_output()` | `recovering` 체크 → `-ENODATA` 반환, wait 중이면 wake |
| `dxrt_write_mem()` | `recovering` 체크 → `-EBUSY` 반환 |
| `dxrt_read_mem()` | `recovering` 체크 → `-EBUSY` 반환 |
| `dxrt_read_event()` | `recovering` 동안 대기, recovery 후 재개 |

이 계층은 kernel DMA subsystem의 admission gate **이전에** 요청을 차단하여
불필요한 SG table 할당, user page pinning 등의 비용을 방지합니다.

### 3.7 `ch_in_use` Reset — Channel 재사용 보장

**위치:** `dx_sgdma.c` → `dx_pcie_reset_dma_channels()`

```c
for (i = 0; i < dw->rd_ch_cnt; i++) {
        spin_lock(&dw->rd_dma_chan_locks[i].ch_lock);
        dw->rd_dma_chan_locks[i].ch_in_use = false;
        spin_unlock(&dw->rd_dma_chan_locks[i].ch_lock);
}
```

Recovery 중 channel의 transfer thread가 비정상 종료되면
`ch_in_use` flag가 true인 채로 남아있을 수 있습니다.
이 flag를 reset하지 않으면 recovery 후에도 해당 channel이
영구적으로 busy로 표시되어 사용 불가합니다.

---

## 4. 보호 계층 요약

Multi-process 환경에서 DMA error recovery 시, 다음 3개 계층이 겹쳐서 보호합니다:

```
┌─────────────────────────────────────────────────────┐
│  Layer 1: RT Driver (dxrt_drv_message.c)            │
│  ┌─────────────────────────────────────────────┐    │
│  │ recovering 플래그 체크                       │    │
│  │ → write_mem, read_mem, npu_run, read_output │    │
│  │ → 새 요청 즉시 -EBUSY/-ENODATA 반환         │    │
│  └─────────────────────────────────────────────┘    │
│                        ↓ (bypass 시)                 │
│  Layer 2: DMA Thread (dw-edma-thread.c)             │
│  ┌─────────────────────────────────────────────┐    │
│  │ Admission Gate (sbr_in_progress + epoch)     │    │
│  │ → doorbell 직전 최종 차단                     │    │
│  │ → -EIO 반환                                  │    │
│  └─────────────────────────────────────────────┘    │
│                        ↓ (이미 wait 중이면)          │
│  Layer 3: In-flight Protection                      │
│  ┌─────────────────────────────────────────────┐    │
│  │ hw_err + wake_up → 즉시 깨움                 │    │
│  │ recovery_epoch → stale thread 보호            │    │
│  │ vc.lock → state machine race 방어             │    │
│  │ notify_peer_channels → 피해 channel 통보      │    │
│  └─────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────┘
```

---

## 5. SBR 발생 조건

SBR은 마지막 수단(`last resort`)으로, 다음 조건에서만 수행됩니다:

```c
/* dx_pcie_reset_dma_channels() */
for (i = 0; i < dw->wr_ch_cnt + dw->rd_ch_cnt; i++) {
        u32 cs = dw_edma_v0_core_ch_status_raw(&dw->chan[i]);
        if (cs == 1 || cs == 2) {
                needs_sbr = true;  /* terminate_all 2-pass 후에도 stuck */
        }
}
```

**SBR 전제조건:**
1. `terminate_all` 2-pass (EDMA_REQ_STOP → ch_soft_reset/engine_cycle) 완료
2. 그럼에도 channel이 CS=1 (Running) 또는 CS=2 (Halted on error) 상태

**SBR 이후:**
- 모든 eDMA channel → CS=3 (Stopped, power-on default)
- DMA engine, channel power, iATU 재초기화
- PCI config space + MSI 복원 (`get_cached_msi_msg` + PCI config write)
- FW는 완전 reset → `dxrt_recovery_device`에서 re-initialization 처리

---

## 6. 관련 파일

| 파일 | 역할 |
|---|---|
| `modules/pci_deepx/include/dw-edma-core.h` | `struct dw_edma` — `sbr_in_progress`, `recovery_epoch`, `alive` 정의 |
| `modules/pci_deepx/dw-edma-thread.c` | `dw_edma_sg_process()` — admission gate, recovery guard, timeout 처리 |
| `modules/pci_deepx/dw-edma-core.c` | `dw_edma_device_terminate_all()` — vc.lock 보호, state machine |
| `modules/pci_deepx/dw-edma-v0-core.c` | `ch_soft_reset()`, `engine_cycle()`, `notify_peer_channels()`, SBR |
| `modules/pci_deepx/dx_sgdma.c` | `dx_pcie_reset_dma_channels()` — recovery orchestration (DMA layer) |
| `modules/pci_deepx/dx_message.c` | `dx_pcie_enqueue_event_response()` — user-space event 전달 |
| `modules/rt/dxrt_drv_message.c` | `dxrt_recovery_device()` — recovery orchestration (RT layer) |
